ABOUT
=====
qrencode-gui - QR Image Generator with GUI.

Qrencode-gui is a graphical user interface to generate QR images, using qrencode as a backend.

Tested on Debian sid.

SCREENSHOT
==========
<a href="http://www.dumpt.com/img/files/szj70q5adgxbjtb1eh1r.png" target="_blank"><img src="http://www.dumpt.com/img/files/szj70q5adgxbjtb1eh1r.png" title="qrencode-gui" alt="qrencode-demo" /></a>

Features
========
* Simple to use.
* Instant QR image generation.
