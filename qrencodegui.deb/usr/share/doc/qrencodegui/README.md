ABOUT
=====
qrencode-gui - QR Image Generator with GUI.

Qrencode-gui is a graphical user interface to generate QR images, using qrencode as a backend.
